/*UID: 105502901
Name: Lisa Wang 
Project 3*/

#include <iostream>
#include <string>
using namespace std;
bool isValidResultString(string results);
int  positiveTests(string results);
int  negativeTests(string results);
int  totalTests(string results);
int  batches(string results);

int main(){
    return 0;
}

bool isValidResultString(string results)
{
    int len = results.length();
    string total_str = "";
    int total_int;
    string positive_str = "";
    int positive_int;
    string negative_str = "";
    int negative_int;
    int batch_reset =0;
    if (len == 0)
    {
        return false;
    }
    if (results[0] != 'R') {
        return false;
    }
    //	cout << results.size() << endl;
    for (int i = 0; i < results.size(); i++) {
        if (results[i] == 'R' || results[i] == '+' || results[i] == '-' || (isdigit(results[i])) == true)
        {
            if (results[i] == 'R' && results[i + 1] == '0')
            {

                return false;
            }
            else if (results[i] == 'R' && (results[i + 1] == '+' || results[i + 1] == '-'))
            {

                return false;
            }
            else if ((results[i] == '+' && results[i + 1] == '-') || (results[i] == '-' && results[i + 1] == '+')) {

                return false;
            }
            else if ((results[i] == '+' && isdigit(results[i + 1]) == false) || (results[i] == '-' && isdigit(results[i + 1]) == false) || (results[i] == 'R' && isdigit(results[i + 1]) == false)) {

                return false;
            }
            else if (results[i] == '0' && results[i + 1] == '0')
                return false;

        }
        else {
            return false;
        }
        if (results[i] == 'R')
        {
            if (batch_reset != 0)
            {
                return false;
            }
            total_str = "";
            i++;
            if (!isdigit(results[i])){
                return false;
            }
            while (isdigit(results[i])) {

                total_str += results[i];
                i++;

            }

            total_int = atoi(total_str.c_str());
            batch_reset = 2;

        }


        if (results[i] == '-')
        {
            i++;
            if (!isdigit(results[i])) {
                return false;
            }
            while (isdigit(results[i])) {
                negative_str += results[i];
                i++;
            }
            negative_int = atoi(negative_str.c_str());

            negative_str = "";
            batch_reset--;

            if (batch_reset == 0) {

                int temp = positive_int + negative_int;
                if (temp != total_int) {
                    return false;
                }
            }
            i--;

        }

        if (results[i] == '+')
        {

            i++;
            if (!isdigit(results[i])) {
                return false;
            }
            positive_str = "";
            while (isdigit(results[i])) {
                positive_str += results[i];
                i++;
            }
            positive_int = atoi(positive_str.c_str());

            batch_reset--;

            if (batch_reset == 0) {
                int temp = positive_int + negative_int;
                if (temp != total_int) {
                    return false;
                }

            }
            i--;
        }
    } // end for
    if (batch_reset != 0) {
        return false;
    }
    return true;
}

int  positiveTests(string results)
{
    int total_positive = 0;
    if (isValidResultString(results)) {
        for (int i = 0; i < results.size(); i++) {
            if (results[i] == '+') {
                i++;
                string positive_str = "";
                while (isdigit(results[i])) {
                    positive_str += results[i];
                    i++;
                }
                total_positive += atoi(positive_str.c_str());
            }
        } // end for
        return total_positive;
    }
    else {
        return -1;
    }
}

int  negativeTests(string results)
{
    int total_negative = 0;
    if (isValidResultString(results)) {
        for (int i = 0; i < results.size(); i++) {
            if (results[i] == '-') {
                i++;
                string negative_str = "";
                while (isdigit(results[i])) {
                    negative_str += results[i];
                    i++;
                }
                total_negative += atoi(negative_str.c_str());
            }
        } // end for
        return total_negative;
    }
    else {
        return -1;
    }
}

int  totalTests(string results)
{
    int total_reported = 0;
    if (isValidResultString(results)) {
        for (int i = 0; i < results.size(); i++) {
            if (results[i] == 'R') {
                i++;
                string total_str = "";
                while (isdigit(results[i])) {
                    total_str += results[i];
                    i++;
                }
                total_reported += atoi(total_str.c_str());
            }
        } // end for
        return total_reported;
    }
    else {
        return -1;
    }
}

int  batches(string results)
{
    int total_batches = 0;
    if (isValidResultString(results)) {
        for (int i = 0; i < results.size(); i++) {
            if (results[i] == 'R') {
                total_batches += 1;
            }
        }//end for
        return total_batches;
    }
    else {
        return -1;
    }
}
